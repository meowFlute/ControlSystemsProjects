function F=ballbeam_ctrl(in,P)
    z_d   = in(1);
    z     = in(2);
    theta = in(3);
    t     = in(4);
    
     % use a digital differentiator to find zdot and thetadot
    persistent zdot
    persistent z_d1
    persistent thetadot
    persistent theta_d1
    % reset persistent variables at start of simulation
    if t<P.Ts,
        zdot        = 0;
        z_d1        = 0;
        thetadot    = 0;
        theta_d1    = 0;
    end
    zdot = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*zdot...
        + 2/(2*P.tau+P.Ts)*(z-z_d1);
    thetadot = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*thetadot...
        + 2/(2*P.tau+P.Ts)*(theta-theta_d1);
    z_d1 = z;
    theta_d1 = theta;

    % construct the state
    ze = P.L/2;
    % NOTE:  remember the feedback control should actually be
    % u_tilde = -K*x_tilde + kr*zd_tilde
    % since the only value that deviates from zero is z, we have
    x_tilde = [theta; z-ze; thetadot; zdot];
    % equilibrium force
    Fe = 0.5*P.m2*P.g + P.m1*P.g*ze/P.L;
    % compute the state feedback controller
    zd_tilde = z_d - ze;
    F_tilde = -P.K*x_tilde + P.kr*zd_tilde;
    F = sat( Fe + F_tilde, P.Fmax);
end



%-----------------------------------------------------------------
% saturation function
function out = sat(in,limit)
    if     in > limit,      out = limit;
    elseif in < -limit,     out = -limit;
    else                    out = in;
    end
end