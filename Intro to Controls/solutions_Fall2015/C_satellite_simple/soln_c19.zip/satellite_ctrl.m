function out=satellite_ctrl(in,P)
    phi_d   = in(1);
    theta   = in(2);
    phi     = in(3);
    t       = in(4);
    
    % implement observer
    persistent xhat       % estimated state (for observer)
    persistent dhat       % estimate disturbance
    persistent tau        % delayed input (for observer)
    if t<P.Ts,
        xhat = [0;0;0;0];
        dhat = 0;
        tau    = 0;
    end
    N = 10;
    for i=1:N,
        xhat = xhat + ...
            P.Ts/N*(P.A*xhat+P.B*(tau+dhat)+ P.L*([theta;phi]-P.C*xhat));
        dhat = dhat + P.Ts/N*P.Ld*([theta;phi]-P.C*xhat);
    end
    
    % integrator
    error = phi_d - phi;
    persistent integrator
    persistent error_d1
    % reset persistent variables at start of simulation
    if t<P.Ts==1,
        integrator  = 0;
        error_d1    = 0;
    end
    if abs(xhat(4))<0.01,  %x4 = phidot
        integrator = integrator + (P.Ts/2)*(error+error_d1);
    end
    error_d1 = error;    

    % compute the state feedback controller
    tau_unsat = -P.K*xhat + P.kr*phi_d + P.ki*integrator + dhat;
    tau = sat( tau_unsat, P.taumax);
    
        % integrator anti-windup
    if P.ki~=0,
       integrator = integrator + P.Ts/P.ki*(tau-tau_unsat);
    end
    
    out = [tau; xhat];

end

%-----------------------------------------------------------------
% saturation function
function out = sat(in,limit)
    if     in > limit,      out = limit;
    elseif in < -limit,     out = -limit;
    else                    out = in;
    end
end