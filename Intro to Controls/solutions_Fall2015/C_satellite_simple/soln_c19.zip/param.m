clear all

% actual system parameters
AP.Js = 5; % kg m^2
AP.Jp = 1;  % kg m^2
AP.k = 0.15; % N m 
AP.b = 0.05; % N m s

% initial conditions
AP.theta0    = 0;
AP.phi0      = 0;
AP.thetadot0 = 0;
AP.phidot0   = 0;

% parameters known to controller
P.Js = AP.Js;%*.95; % kg m^2
P.Jp = AP.Jp;%*1.05;  % kg m^2
P.k = AP.k;%*.95; % N m 
P.b = AP.b;%*1.05; % N m s

% maximum torque
P.taumax = 5; %Nm

% sample rate for controller
P.Ts = 0.01;

% gain for dirty derivative
P.tau = 0.05;

% % PD design for inner loop
% A_th    = 60*pi/180; 
% zeta_th = 0.707;
% P.kp_th = P.taumax/A_th;
% wn_th = sqrt((P.k+P.kp_th)/P.Js);
% P.kd_th = 2*zeta_th*wn_th*P.Js - P.b;
% 
% % inner loop poles
% roots([1, 2*zeta_th*wn_th, wn_th^2])
% 
% 
% % DC gain for inner loop
% k_DC_th = P.kp_th/(P.k+P.kp_th);
% 
% % outer loop design
% A_phi = 30*pi/180;
% P.kp_phi = A_th/A_phi;
% 
% % outer loop pole
% -k_DC_th*P.kp_phi/(1+k_DC_th*P.kp_phi);
% 
% % DC gain of outer loop
% k_DC_phi = k_DC_th*P.kp_phi/(1+k_DC_th*P.kp_phi);
% 
% % draw root locus
% L = tf([P.b/P.Jp],[1,(P.b/P.Jp+P.b*P.kp_phi/P.Jp),0]);
% figure(2), clf, rlocus(L);
% 
% % select integrator gain
% P.ki_phi = 0.15;

% state space design
P.A = [...
    0, 0, 1, 0;...
    0, 0, 0, 1;...
    -P.k/P.Js, P.k/P.Js, -P.b/P.Js, P.b/P.Js;...
    P.k/P.Jp, -P.k/P.Jp, P.b/P.Jp, -P.b/P.Jp;...

];
P.B = [0; 0; 1/P.Js; 0];
P.C = [...
    1, 0, 0, 0;...
    0, 1, 0, 0;...
    ];

% form augmented system
Cout = [0,1,0,0];
A1 = [P.A, zeros(4,1); Cout, 0];
B1 = [P.B; 0];

% gains for pole locations
wn_th   = 0.9924;
zeta_th = 0.707;
wn_phi    = 1.5;
zeta_phi  = 0.707;
ol_char_poly = charpoly(P.A);
des_char_poly = conv(conv([1,2*zeta_th*wn_th,wn_th^2],...
                          [1,2*zeta_phi*wn_phi,wn_phi^2]),...
                     poly(-.1));
des_poles = roots(des_char_poly);

% is the system controllable?
if rank(ctrb(A1,B1))~=5, 
    disp('System Not Controllable'); 
else % if so, compute gains
    K1   = place(A1,B1,des_poles); 
    P.K  = K1(1:4);
    P.ki = K1(5);
    P.kr = -1/(Cout*inv(P.A-P.B*P.K)*P.B);
end

% observer design
% form augmented system for disturbance observer
A2 = [P.A, P.B; zeros(1,4), zeros(1,1)];
C2 = [P.C, zeros(2,1)];
% pick observer poles
wn_th_obs   = 10*wn_th;
wn_phi_obs    = 10*wn_phi;
des_obsv_char_poly = conv([1,2*zeta_phi*wn_phi_obs,wn_phi_obs^2],...
                      [1,2*zeta_th*wn_th_obs,wn_th_obs^2]);
des_obsv_poles = roots(des_obsv_char_poly);
dist_obsv_pole = -1;

% is the system observable?
if rank(obsv(A2,C2))~=5, 
    disp('System Not Observable'); 
else % if so, compute gains
    L2 = place(A2', C2', [des_obsv_poles;dist_obsv_pole])';
    P.L = L2(1:4,:);
    P.Ld = L2(5,:);
end




