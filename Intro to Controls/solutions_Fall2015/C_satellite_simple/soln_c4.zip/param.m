% actual system parameters
AP.Js = 5; % kg m^2
AP.Jp = 1;  % kg m^2
AP.k = 0.15; % N m 
AP.b = 0.05; % N m s

% initial conditions
AP.theta0    = 0;
AP.psi0      = 0;
AP.thetadot0 = 0;
AP.psidot0   = 0;

% parameters known to controller
P.Js = 5; % kg m^2
P.Jp = 1;  % kg m^2
P.k = 0.15; % N m 
P.b = 0.05; % N m s
