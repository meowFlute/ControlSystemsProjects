% actual system parameters
AP.Js = 5; % kg m^2
AP.Jp = 1;  % kg m^2
AP.k = 0.15; % N m 
AP.b = 0.05; % N m s

% initial conditions
AP.theta0    = 0;
AP.phi0      = 0;
AP.thetadot0 = 0;
AP.phidot0   = 0;

% parameters known to controller
P.Js = 5; % kg m^2
P.Jp = 1;  % kg m^2
P.k = 0.15; % N m 
P.b = 0.05; % N m s

% maximum torque
P.taumax = 5; %Nm

% PD inner loop design
A_th    = 60*pi/180; 
zeta_th = 0.707;
P.kp_th = P.taumax/A_th;
wn_th = sqrt((P.k+P.kp_th)/P.Js);
P.kd_th = 2*zeta_th*wn_th*P.Js - P.b;

% inner loop poles
roots([1, 2*zeta_th*wn_th, wn_th^2]);

% compute DC gain of inner loop
k_DC_in = P.kp_th/(P.k+P.kp_th);

% outer loop design
P.A_phi = 30*pi/180;
P.kp_phi = A_th/P.A_phi;

% outer loop pole
-k_DC_in*P.kp_phi/(1+k_DC_in*P.kp_phi);

% DC gain of outer loop
k_DC_out = k_DC_in*P.kp_phi/(1+k_DC_in*P.kp_phi);

P.ki_th = 0.01;
P.ki_phi = 0.1;

P.Ts = 0.01;
P.tau = 0.05;

% transfer functions
P_in = tf([1/P.Js],[1,P.b/P.Js,P.k/P.Js]);
P_out = tf([P.b/P.Jp],[1,P.b/P.Jp]);

C_in_pd = tf([(P.kd_th+P.tau*P.kp_th), P.kp_th], [P.tau, 1]);
C_out_p = P.kp_phi;
C_out_pi = tf([P.kp_phi, P.ki_phi],[1,0])

figure(1), clf, 
bode(P_in), grid on
hold on
bode(series(C_in_pd,P_in))
legend('No control', 'PD')
title('Satellite, Inner Loop')

figure(2), clf, 
bode(P_out), grid on
hold on
bode(series(C_out_p,P_out))
bode(series(C_out_pi,P_out))
legend('No control', 'P','PI')
title('Satellite, Outer Loop')



