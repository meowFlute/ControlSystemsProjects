% actual system parameters
AP.Js = 5; % kg m^2
AP.Jp = 1;  % kg m^2
AP.k = 0.15; % N m 
AP.b = 0.05; % N m s

% initial conditions
AP.theta0    = 0;
AP.phi0      = 0;
AP.thetadot0 = 0;
AP.phidot0   = 0;

% parameters known to controller
P.Js = 5; % kg m^2
P.Jp = 1;  % kg m^2
P.k = 0.15; % N m 
P.b = 0.05; % N m s

% PD design for inner loop
tr_th    = 2;
wn_th    = 2.2/tr_th;
zeta_th  = 0.707;
P.kp_th  = wn_th^2*P.Js-P.k;
P.kd_th  = 2*zeta_th*wn_th*P.Js-P.b;
roots([1,(P.b+P.kd_th)/P.Js, (P.k+P.kd_th)/P.Js])

% DC gain for inner loop
k_DC_th = P.kp_th/(P.k+P.kp_th);

%PD design for outer loop
tr_phi     = 2*tr_th;
P.kp_phi   = (P.Jp/tr_phi - P.b)/P.b/k_DC_th;

k_DC_phi = P.b*k_DC_th*P.kp_th/(P.b+P.b*k_DC_th*P.kp_th);

roots([1,P.b*(1+k_DC_th*P.kp_phi)/P.Jp])


