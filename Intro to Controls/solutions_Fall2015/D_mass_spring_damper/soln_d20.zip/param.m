clear all

% actual system parameters
AP.m = 5;  % kg
AP.k = 3;  % Kg/s^2
AP.b = 0.5; % Kg/s
% input constraint
AP.Fmax = 2;
% initial conditions
AP.y0 = 0;
AP.ydot0 = 0;

% parameters known to the controller 
P.m = AP.m*.95;  % kg
P.k = AP.k*1.05;  % Kg/s^2
P.b = AP.b*0.9; % Kg/s
P.Fmax = AP.Fmax;
P.Ts = 0.01;  % sample rate for controller
P.tau = 0.05; % gain for dirty derivative

% maximum omega_n 
A = 0.25;
zeta = 1/sqrt(2);
P.kp = P.Fmax/A;
wn = sqrt((P.k+P.kp)/P.m);
P.kd = 2*zeta*wn*P.m-P.b;
P.ki = 0.5;

% closed loop poles
roots([1,2*zeta*wn,wn^2]);

% transfer function for robot arm
G = tf([1/P.m],[1, P.b/P.m, P.k/P.m]);
C_pd = tf([(P.kd+P.tau*P.kp), P.kp], [P.tau, 1]);
C_pid = tf([(P.kd+P.kp*P.tau),(P.kp+P.ki*P.tau),P.ki],[P.tau,1,0]);

figure(1), clf, bode(G), grid on

