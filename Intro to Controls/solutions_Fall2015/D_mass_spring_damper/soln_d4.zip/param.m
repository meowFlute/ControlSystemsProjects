% system parameters
AP.m = 5;  % kg
AP.k = 3;  % Kg/s^2
AP.b = 0.5; % Kg/s


% initial conditions
AP.y0 = 0;
AP.ydot0 = 0;
