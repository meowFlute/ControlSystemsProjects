clear all

% actual system parameters
AP.m = 5;  % kg
AP.k = 3;  % Kg/s^2
AP.b = 0.5; % Kg/s


% initial conditions
AP.y0 = 0;
AP.ydot0 = 0;

% parameters known to controller
P.m = AP.m * .95;  % kg
P.k = AP.k * 1.01;  % Kg/s^2
P.b = AP.b * 1.05; % Kg/s

% sample time for controller
P.Ts = 0.01;

% dirty derivative gain
P.tau = 0.1;

% input constraint
P.Fmax = 2;

% % maximum omega_n 
% A = 1;
% Fmax = P.Fmax - P.k*A/4;
% zeta = 0.707;
% P.kp = Fmax/A
% wn = sqrt((P.k+P.kp)/P.m)
% P.kd = 2*zeta*wn*P.m-P.b
% 
% % closed loop poles
% roots([1,2*zeta*wn,wn^2])
% 
% % plot root locus 
% %figure(2), clf
% %rlocus([1/P.m], [1, (P.b+P.kd)/P.m, (P.k+P.kp)/P.m, 0])
% 
% % pick integrator gain
% P.ki = 0.3;

% state space design 
P.A = [...
    0, 1;...
    -P.k/P.m, -P.b/P.m;...
    ];
P.B = [0; 1/P.m ];
P.C = [...
    1, 0;...
    ];

% form augmented system
A1 = [P.A, zeros(2,1); P.C, 0];
B1 = [P.B; 0];

% gains for pole locations
wn = 0.922;
zeta = 0.707;

ol_char_poly = charpoly(P.A);
des_char_poly = conv([1,2*zeta*wn,wn^2],poly(-.5));
des_poles = roots(des_char_poly);


% is the system controllable?
if rank(ctrb(A1,B1))~=3, 
    disp('System Not Controllable'); 
else % if so, compute gains
    K1   = place(A1,B1,des_poles); 
    P.K  = K1(1:2);
    P.ki = K1(3);
    P.kr = -1/(P.C*inv(P.A-P.B*P.K)*P.B);
end

% observer design
% form augmented system for disturbance observer
A2 = [P.A, P.B; zeros(1,2), 0];
C2 = [P.C, 0];
% pick observer poles
wn_obs = 10*wn;
des_obs_poles = roots([1, 2*zeta*wn_obs, wn_obs^2]);
dist_pole = -1;


% is the system observable?
if rank(obsv(A2,C2))~=3, 
    disp('System Not Observable'); 
else % if so, compute gains
    L2 = place(A2',C2',[des_obs_poles;dist_pole])'; 
    P.L = L2(1:2);
    P.Ld = L2(3);
end

