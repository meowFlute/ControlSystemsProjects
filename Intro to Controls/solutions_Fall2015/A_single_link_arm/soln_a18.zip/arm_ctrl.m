function out=arm_ctrl(in,P)
    theta_c = in(1);
    theta   = in(2);
    t       = in(3);
    
    % compute equilibrium torque tau_e
    theta_e = 0;
    tau_e = P.m*P.g*(P.ell/2)*cos(theta);
    x_e = [theta_e; 0];

    % implement observer
    persistent xhat       % estimated state (for observer)
    persistent tau         % delayed input (for observer)
    if t<P.Ts,
        xhat  = [0; 0];
        tau   = 0;
    end
    N = 10;
    for i=1:N,
        xhat = xhat + ...
            P.Ts/N*(P.A*(xhat-x_e)+P.B*(tau-tau_e)+ P.L*(theta-P.C*xhat));
    end
    
    % compute the state feedback controller
    tau_tilde = - P.K*(xhat-x_e) + P.kr*(theta_c-theta_e);
    % compute total torque
    tau = sat( tau_e + tau_tilde, P.tau_max);
        
    out = [tau; xhat];
end

function out = sat(in,limit)
    if     in > limit,      out = limit;
    elseif in < -limit,     out = -limit;
    else                    out = in;
    end
end