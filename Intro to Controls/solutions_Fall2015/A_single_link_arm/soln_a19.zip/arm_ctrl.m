function out=arm_ctrl(in,P)
    theta_c = in(1);
    theta   = in(2);
    t       = in(3);
    
    % compute equilibrium torque tau_e
    theta_e = 0;
    tau_e = P.m*P.g*(P.ell/2)*cos(theta);
    x_e = [theta_e; 0];

    % implement observer
    persistent xhat       % estimated state (for observer)
    persistent dhat       % estimate disturbance
    persistent tau         % delayed input (for observer)
    if t<P.Ts,
        xhat  = [0; 0];
        dhat  = 0;
        tau   = 0;
    end
    N = 10;
    for i=1:N,
        xhat = xhat + ...
            P.Ts/N*(P.A*(xhat-x_e)+P.B*(tau-tau_e+dhat)+ P.L*(theta-P.C*xhat));
        dhat = dhat + P.Ts/N*P.Ld*(theta-P.C*xhat);
    end
    
    % add integrator
    error = theta_c - theta;
    persistent integrator
    persistent error_d1
    % reset persistent variables at start of simulation
    if t<P.Ts==1,
        integrator  = 0;
        error_d1    = 0;
    end
    if abs(xhat(2))<0.05,
        integrator = integrator + (P.Ts/2)*(error+error_d1);
    end
    error_d1 = error;

    % compute the state feedback controller
    tau_tilde = - P.K*(xhat-x_e) + P.kr*(theta_c-theta_e) + P.ki*integrator;
    % compute total torque
    tau = sat( tau_e + tau_tilde - dhat, P.tau_max);
    
    % integrator anti-windup
    if P.ki~=0,
       tau_unsat = tau_e + tau_tilde - dhat;
       integrator = integrator + P.Ts/P.ki*(tau-tau_unsat);
    end

    out = [tau; xhat];
    
end

function out = sat(in,limit)
    if     in > limit,      out = limit;
    elseif in < -limit,     out = -limit;
    else                    out = in;
    end
end