clear all

% actual system parameters
AP.m = 0.5;   % kg
AP.ell = 0.3; % m
AP.b = 0.01;  % N m s
AP.g = 9.8;   % m/s^2

% initial conditions
AP.theta0 = 0;
AP.thetadot0 = 0;

% parameters known to controller
P.m = AP.m*0.95;   % kg
P.ell = AP.ell*1.05; % m
P.b = AP.b*0.97;  % N m s
P.g = 9.8;   % m/s^2

% sample rate
P.Ts = 0.01;

% dirty derivative gain
P.tau = 0.05;

% equalibrium torque
P.theta_e = 0*pi/180;
P.tau_e   = P.m*P.g*P.ell/2*cos(P.theta_e);

% saturation constraint
P.tau_max = 1;
tau_max = P.tau_max-P.tau_e;

% % select PD gains
% A_th = 50*pi/180;
% zeta = 0.707;
% P.kp = tau_max/A_th;
% wn = sqrt(3*P.kp/(P.m*P.ell^2));
% P.kd = 2*zeta*wn*(P.m*P.ell^2)/3-P.b;
% 
% roots([1,2*zeta*wn,wn^2]);

% draw root locus
%L = tf([3/P.m/P.ell^2],[1,(3*P.b+3*P.kd)/P.m/P.ell^2,3*P.kp/P.m/P.ell^2,0]);
%figure(2), clf, rlocus(L);

% select integrator gain
% P.ki = 0.1;

%---------------------
% state space design 
P.A = [...
    0, 1;...
    0, -3*P.b/P.m/(P.ell^2);...
    ];
P.B = [0; 3/P.m/(P.ell^2) ];
P.C = [...
    1, 0;...
    ];
% form augmented system for integrator
A1 = [P.A, zeros(2,1); P.C, 0];
B1 = [P.B; 0];

% desired pole locations
wn = 4.4117;
zeta = 0.707;
des_char_poly = conv([1,2*zeta*wn,wn^2],poly(-.5));
des_poles = roots(des_char_poly);

% is the system controllable?
if rank(ctrb(A1,B1))~=3, 
    disp('System Not Controllable'); 
else % if so, compute gains
    K1   = place(A1,B1,des_poles); 
    P.K  = K1(1:2);
    P.ki = K1(3);
    P.kr = -1/(P.C*inv(P.A-P.B*P.K)*P.B);
end

% observer design
% form augmented system for disturbance observer
A2 = [P.A, P.B; zeros(1,2), 0];
C2 = [P.C, 0];
% pick observer poles
a = 10;
q1 = -a + j*a;
q2 = -a - j*a;
qd = -.5;

% is the system observable?
if rank(obsv(A2,C2))~=3, 
    disp('System Not Observable'); 
else % if so, compute gains
    L2 = place(A2',C2',[q1,q2,qd])'; 
    P.L = L2(1:2);
    P.Ld = L2(3);
end









