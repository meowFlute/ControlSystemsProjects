%--------------------------------------------------------
% actual parameters - used in physics model in simulation
% actual system parameters
AP.m = 0.5;  % kg
AP.ell = 0.3; % m
AP.b = 0.01; % N m s
AP.g = 9.8; % m/s^2
% actual initial conditions
AP.theta0 = 0;
AP.thetadot0 = 0;
% input constraint
AP.tau_max = 2;

%--------------------------------------------------------
% control parameters - these are the parameters known to the controller,
% which may not be the actual parameters
P.m = AP.m*(0.9);  % kg
P.ell = AP.ell*(0.95); % m
P.b = AP.b*(1.1); % N m s
P.g = AP.g; % m/s^2
% initial conditions
P.theta0 = AP.theta0;
P.thetadot0 = AP.thetadot0;
% input constraint
P.tau_max = AP.tau_max;

% equalibrium torque
P.theta_e = 0;
P.tau_e = P.m*P.g*P.ell/3*cos(P.theta_e);

% select PD gains
A_th = 50*pi/180;
zeta = 1;%0.707;
P.kp_th = (P.tau_max-P.tau_e)/A_th;
wn = sqrt(3*P.kp_th/P.m/P.ell^2);
P.kd_th = P.m*P.ell^2/3*2*zeta*wn-P.b;

% draw root locus
%figure(2), clf
%L = tf(3/P.m/P.ell^2,[1,3*(P.b+P.kd_th)/P.m/P.ell^2,3*P.kp_th/P.m/P.ell^2,0]);
%figure(2), rlocfind(L)
P.ki_th = 0.1;

% sample rate
P.Ts = 0.01;

% dirty derivative gain
P.tau = 0.05;


% transfer function for robot arm
th_e = 0;
G = tf([2/P.m/P.ell^2],[1, 2*P.b/P.m/P.ell^2, -3*P.g*sin(th_e)/2/P.ell]);
%figure(1), clf, bode(G), grid on


C_pd = tf([(P.kd_th+P.kp_th*P.tau),P.kp_th],[P.tau,1])
C_pid = tf([(P.kd_th+P.kp_th*P.tau),(P.kp_th+P.ki_th*P.tau),P.ki_th],[P.tau,1,0])

figure(2), clf, bode(G), grid on
hold on
bode(G*C_pd) 
bode(G*C_pid)
legend('plant', 'PD control', 'PID control')

