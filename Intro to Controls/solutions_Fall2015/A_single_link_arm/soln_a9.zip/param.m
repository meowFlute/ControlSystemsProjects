% system parameters
AP.m = 0.5;  % kg
AP.ell = 0.3; % m
AP.b = 0.01; % N m s
AP.g = 9.8; % m/s^2


% initial conditions
AP.theta0 = 0;
AP.thetadot0 = 0;

% parameters known to controller
P.m = 0.5;  % kg
P.ell = 0.3; % m
P.b = 0.01; % N m s
P.g = 9.8; % m/s^2


% equalibrium torque
P.theta_e = 0*pi/180;
P.tau_e = P.m*P.g*P.ell/2*cos(P.theta_e);

P.kp = 0.18;
P.kd = 0.095;
