% start with pid control designed in problem 15
figure(1), clf
    bode(Plant*C_pid)
    hold on
    grid on
 figure(2), clf
    bodemag(Plant*C_pid)
    hold on
    grid on
    % add constraints

%         % tracking constraint
%         omega_r = 10^-3;  % track signals below this frequency
%         gamma_r = 0.001;  % tracking error below this value
%         w = logspace(log10(omega_r)-2,log10(omega_r));
%         plot(w,20*log(1/gamma_r)*ones(size(w)),'g')
        
%         % output disturbance constraint
%         omega_dout = 10^-3;  % reject output disturbances below this frequency
%         gamma_dout = 0.001;  % amountn of output disturbance in output
%         w = logspace(log10(omega_dout)-2,log10(omega_dout));
%         plot(w,20*log(1/gamma_dout)*ones(size(w)),'g')

%         % Reject input disturbances with frequence content below $\omega_{d_{in}}=0.1$~rad/sec by $\gamma_{d_{in}}=0.1$.
%         % input disturbance constraint
%         omega_din = 10^-1;  % reject input disturbances below this frequency
%         gamma_din = 0.1;  % amountn of input disturbance in output
%         w = logspace(log10(omega_din)-2,log10(omega_din));
%         Pmag=bode(P,w);
%         for i=1:size(Pmag,3), Pmag_(i)=Pmag(1,1,i); end
%         plot(w,20*log10(1/gamma_din)*ones(1,length(Pmag_))+20*log10(Pmag_),'g')

%         % Attenuate noise with frequency content above $\gamma_n=10$~rad/sec by $\gamma_n = 0.1$.
%         % noise constraint
%         omega_n = 10^1;  % attenuate noise above this frequency
%         gamma_n = .1;   % attenuate noise by this amount
%         w = logspace(log10(omega_n),2+log10(omega_n));
%         plot(w,20*log10(gamma_n)*ones(size(w)),'g')
        
%         % steady state tracking of step
%         gamma_0 = .01;
%         w = logspace(-5, 0);
%         plot(w,20*log10(1/gamma_0 -1)*ones(size(w)),'g')
        
%         % Track a ramp within $\gamma_1=0.03$.
%         % steady state tracking of ramp
%         gamma_1 = .03;
%         w = logspace(-4, 0);
%         plot(w,20*log10(1/gamma_1)-20*log10(w),'g')

%         % steady state tracking of parabola
%         gamma_2 = .01;
%         w = logspace(-5, 0);
%         plot(w,20*log10(1/gamma_2)-40*log10(w),'g')

    
% Control transfer function


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Control Design
     C = C_pid;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% proportional control: change cross over frequency
     kp = .9;
     C = C*kp;
%      figure(1), margin(Plant*C), figure(2), bodemag(Plant*C) % update plot
     
% phase lag (|p|<|z|): add gain at low frequency (tracking, dist rejection)
     % low frequency gain = K*z/p
     % high frequency gain = K
     z = .7;
     p = z/10;
     Lag = tf([1,z],[1,p]);
     C = C*Lag;
     figure(1), margin(Plant*C), figure(2), bodemag(Plant*C) % update plot

% % integral control: increase steady state tracking and dist rejection
%      k_I = .4;
%      Integrator = tf([1,k_I],[1,0]);
%      C = C*Integrator;
%      figure(1), margin(Plant*C), figure(2), bodemag(Plant*C) % update plot


% phase lead (|p|>|z|): increase PM (stability)
     % low frequency gain = K*z/p
     % high frequency gain = K
     wmax = 30; % location of maximum frequency bump
     M   = 8; % separation between zero and pole
     Lead =tf(M*[1,wmax/sqrt(M)],[1,wmax*sqrt(M)]);
     C = C*Lead;
     figure(1), margin(Plant*C), figure(2), bodemag(Plant*C) % update plot

% low pass filter: decrease gain at high frequency (noise)
     p = 50;
     LPF = tf(p,[1,p]);
     C = C*LPF;
     %figure(1), margin(Plant*C), figure(2), bodemag(Plant*C) % update plot

% % low pass filter: decrease gain at high frequency (noise)
%      p = 150;
%      LPF = tf(p,[1,p]);
%      C = C*LPF;
%      %figure(1), margin(Plant*C), figure(2), bodemag(Plant*C) % update plot

figure(1), margin(Plant*C), figure(2), bodemag(Plant*C) % update plot

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% add a prefilter to eliminate the overshoot
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

F = 1;

% notch filter: reduce closed loop peaking at cross over
     ws = 1;  % frequency to start the notch
     we = 10;  % frequency to stop the notch
     p1 = ws; 
     p2 = we; 
     z1 = sqrt(ws*we);
     z2 = z1;
     NOTCH = tf(p1*p2/z1/z2*[1,z1+z2,z1*z2],[1,p1+p2,p1*p2]);
     F = F*NOTCH;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create plots
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Open-loop tranfer function 
OPEN = Plant*C;
% closed loop transfer function from R to Y
CLOSED_R_to_Y = (Plant*C/(1+Plant*C));
% closed loop transfer function from R to U
CLOSED_R_to_U = (C/(1+C*Plant));

figure(3), clf
    subplot(3,1,1), 
        bodemag(CLOSED_R_to_Y), hold on
        bodemag(CLOSED_R_to_Y*F)
        title('Closed Loop Bode Plot'), grid on
    subplot(3,1,2), 
        step(CLOSED_R_to_Y), hold on
        step(CLOSED_R_to_Y*F)
        title('Closed loop step response'), grid on
    subplot(3,1,3), 
        step(CLOSED_R_to_U), hold on
        step(CLOSED_R_to_U*F)
        title('Control effort for step response'), grid on
        
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Convert controller to state space equations for implementation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[num,den] = tfdata(C,'v');
[P.A_C,P.B_C,P.C_C,P.D_C]=tf2ss(num,den);

[num,den] = tfdata(F,'v');
[P.A_F, P.B_F, P.C_F, P.D_F] = tf2ss(num,den);

