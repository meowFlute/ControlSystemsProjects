% system parameters
AP.m = 0.5;  % kg
AP.ell = 0.3; % m
AP.b = 0.01; % N m s
AP.g = 9.8; % m/s^2


% initial conditions
AP.theta0 = 0;
AP.thetadot0 = 0;

% input constraint
AP.taumax = 1;

% equalibrium torque
AP.theta_e = 0;
AP.taue = AP.m*AP.g*AP.ell/3*cos(AP.theta_e);

% maximum omega_n 
zeta = 1/sqrt(2);
M = (3/AP.m/AP.ell^2)*(AP.taumax-AP.taue);
A = 10*pi/180;
wn_max = sqrt(M/A*sqrt(1-zeta^2));
wn = 0.9*wn_max;
tr = pi/2/wn/sqrt(1-zeta^2)


