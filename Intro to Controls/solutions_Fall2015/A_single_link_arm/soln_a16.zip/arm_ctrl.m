function tau=arm_ctrl(in,P)
    theta_c = in(1);
    theta   = in(2);
    t       = in(3);
    
    % use a digital differentiator to find thetadot
    persistent thetadot
    persistent theta_d1
    % reset persistent variables at start of simulation
    if t<P.Ts,
        thetadot    = 0;
        theta_d1    = 0;
    end
    thetadot = (2*P.tau-P.Ts)/(2*P.tau+P.Ts)*thetadot...
        + 2/(2*P.tau+P.Ts)*(theta-theta_d1);
    theta_d1 = theta;
    
    % construct the state
    x = [theta; thetadot];
    % compute equilibrium torque tau_e
    tau_e = P.m*P.g*(P.ell/2)*cos(theta);   
    % compute the state feedback controller
    tau_tilde = - P.K*x + P.kr*theta_c;
    % compute total torque
    tau = sat( tau_e + tau_tilde, P.tau_max);
end

function out = sat(in,limit)
    if     in > limit,      out = limit;
    elseif in < -limit,     out = -limit;
    else                    out = in;
    end
end