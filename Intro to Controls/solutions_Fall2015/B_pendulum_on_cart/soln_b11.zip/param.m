% inverted Pendulum parameter file

% actual system parameters used in simulation model
AP.m1 = 0.25;  % kg
AP.m2 = 1;     % kg
AP.ell = 0.5; % m
AP.b = 0.05; % N m
AP.g = 9.8; % m/s^2


% initial conditions
AP.z0 = 0;
AP.zdot0 = 0;
AP.theta0 = 0;
AP.thetadot0 = 0;

% system parameters used for design
P.m1 = AP.m1;  % kg
P.m2 = AP.m2;     % kg
P.ell = AP.ell; % m
P.b = AP.b; % N m
P.g = 9.8; % m/s^2

% PD design for inner loop
tr_theta = .5;
wn_th    = 2.2/tr_theta;
P.kp_th  = -(P.m1+P.m2)*P.g - P.m2*P.ell*wn_th^2
P.kd_th  = -2*zeta_th*wn_th*P.m2*P.ell

% DC gain for inner loop
k_DC_th = P.kd_th/((P.m1+P.m2)*P.g+P.kp_th)

%PD design for outer loop
tr_z     = 50*tr_theta;
zeta_z   = 0.707;
wn_z     = 2.2/tr_z;
P.kp_z   = P.m2*wn_z^2/P.m1/P.g/k_DC_th
P.kd_z   = (2*zeta_z*wn_z*P.m2-P.b)/P.m1/P.g/k_DC_th

