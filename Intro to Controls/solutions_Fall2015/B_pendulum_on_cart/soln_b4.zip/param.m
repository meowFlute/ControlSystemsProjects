% system parameters
AP.m1 = 0.25;  % kg
AP.m2 = 1;     % kg
AP.ell = 0.5; % m
AP.b = 0.05; % N m
AP.g = 9.8; % m/s^2


% initial conditions
AP.z0 = 0;
AP.zdot0 = 0;
AP.theta0 = 0;
AP.thetadot0 = 0;

% specs
Fmax = 1.5; % N
M = Fmax/AP.m2;
A = 0.1; % m
zeta = 1/sqrt(2);
wn_max = sqrt(M/A*sqrt(1-zeta^2))
wn = 0.9*wn_max
tr = 1/2*pi/wn/sqrt(1-zeta^2)